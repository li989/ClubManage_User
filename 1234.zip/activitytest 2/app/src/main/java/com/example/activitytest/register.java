package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.club.control.example.SchoolNoticeManager;
import com.example.club.control.example.UserManager;
import com.example.club.model.Beanuser;
import com.example.club.util.BaseException;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        Button button1=(Button)findViewById(R.id.login_register);
        Button btnexit=(Button)findViewById(R.id.register_exit);
        Button btnre=(Button)findViewById(R.id.register_release2);
        btnexit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();

            }
        });
        final EditText editText1=(EditText)findViewById(R.id.register_mima2);
        final EditText editText2=(EditText)findViewById(R.id.register_yuanmima2);
        final EditText edtmobile=(EditText)findViewById(R.id.register_photo2);
        final TextView error=(TextView)findViewById(R.id.register_error);
        final EditText edtzh=(EditText)findViewById(R.id.register_zhang2);
        btnre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editText1.getText().toString().equals(editText2.getText().toString()))
                    new Thread(){
                        @Override
                        public void run() {
                            try {
                                UserManager a=new UserManager();
                                Beanuser user=new Beanuser();
                                user.setC_mobile(edtmobile.getText().toString());
                                user.setC_pwd(editText1.getText().toString());
                                user.setC_number(edtzh.getText().toString());
                                a.createuser(user);
                            } catch (BaseException e) {
                                e.printStackTrace();
                            }
                        }
                    }.start();
                finish();
            }
        });


        editText2.addTextChangedListener(new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(!editText1.getText().toString().equals(editable.toString())){
                    error.setText("输入密码不一致");
                }else {
                    error.setText("");
                }
            }
        });

    }
}
