package com.example.club.model;

public class Beanplace {
    private int place_ID;
    private String place_name;
    private String place_status;
	public int getPlace_ID() {
		return place_ID;
	}
	public void setPlace_ID(int place_ID) {
		this.place_ID = place_ID;
	}
	public String getPlace_name() {
		return place_name;
	}
	public void setPlace_name(String place_name) {
		this.place_name = place_name;
	}
	public String getPlace_status() {
		return place_status;
	}
	public void setPlace_status(String place_status) {
		this.place_status = place_status;
	}
    
}
