package com.example.club.model;

public class Beanclub_label {
    private int label_ID;
    private int club_ID;

    public int getLabel_ID() {
        return label_ID;
    }

    public void setLabel_ID(int label_ID) {
        this.label_ID = label_ID;
    }

    public void setClub_ID(int club_ID) {
        this.club_ID = club_ID;
    }

    public int getClub_ID() {
        return club_ID;
    }
}
