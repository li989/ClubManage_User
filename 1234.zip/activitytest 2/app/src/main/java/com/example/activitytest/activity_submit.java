package com.example.activitytest;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class activity_submit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.club_all);
    }
}
