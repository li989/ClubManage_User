package com.example.club.model;

public class Beanuser_label {
    private int label_ID;
    private int c_user_ID;

    public int getLabel_ID() {
        return label_ID;
    }

    public int getC_user_ID() {
        return c_user_ID;
    }

    public void setLabel_ID(int label_ID) {
        this.label_ID = label_ID;
    }

    public void setC_user_ID(int c_user_ID) {
        this.c_user_ID = c_user_ID;
    }
}
