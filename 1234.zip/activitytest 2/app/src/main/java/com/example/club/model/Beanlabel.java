package com.example.club.model;

public class Beanlabel {
    private  int label_ID;
    private String label_name;
    public void setID(int label_ID) {
        this.label_ID = label_ID;
    }

    public void setName(String label_name) {
        this.label_name = label_name;
    }

    public int getID() {
        return label_ID;
    }

    public String getName() {
        return label_name;
    }
}
